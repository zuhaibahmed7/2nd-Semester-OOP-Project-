use employee;
insert into employees (id, name, designation, salary, department) values (1,"Zuhaib","Peon",123456, "Saff");  
USE employee;

INSERT INTO employees (id, name, designation, salary, department) VALUES 
(2, 'Ali Khan', 'Manager', 85000, 'Sales'),
(3, 'Sara Ahmed', 'HR Executive', 55000, 'HR'),
(4, 'Bilal Raza', 'Developer', 95000, 'IT'),
(5, 'Ayesha Noor', 'Accountant', 60000, 'Finance'),
(6, 'Usman Tariq', 'Office Assistant', 30000, 'Admin');

SHOW CREATE TABLE employees;  -- shows primary key.
select * from employees;



