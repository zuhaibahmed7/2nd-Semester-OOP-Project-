import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

class Employee {
    String name;
    int id;
    String designation;
    int salary;
    String department;

    public Employee(String name, int id, String designation, int salary, String department) {
        this.name = name;
        this.id = id;
        this.designation = designation;
        this.salary = salary;
        this.department = department;
    }
}

class DBConnection {
    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_db", "root", "your_password");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

public class EmployeeManagementGUI extends JFrame {
    public EmployeeManagementGUI() {
        setTitle("Employee Management System");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 1));

        JButton addBtn = new JButton("Add Employee");
        JButton displayBtn = new JButton("Display Employees");
        JButton searchBtn = new JButton("Search Employee");
        JButton editBtn = new JButton("Edit Employee");
        JButton deleteBtn = new JButton("Delete Employee");

        addBtn.addActionListener(e -> addEmployee());
        displayBtn.addActionListener(e -> displayEmployees());
        searchBtn.addActionListener(e -> searchEmployee());
        editBtn.addActionListener(e -> editEmployee());
        deleteBtn.addActionListener(e -> deleteEmployee());

        add(addBtn);
        add(displayBtn);
        add(searchBtn);
        add(editBtn);
        add(deleteBtn);

        setVisible(true);
    }

    private void addEmployee() {
        String name = JOptionPane.showInputDialog("Enter Name:");
        int id = Integer.parseInt(JOptionPane.showInputDialog("Enter ID:"));
        String designation = JOptionPane.showInputDialog("Enter Designation:");
        int salary = Integer.parseInt(JOptionPane.showInputDialog("Enter Salary:"));
        String department = JOptionPane.showInputDialog("Enter Department:");

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO employees (id, name, designation, salary, department) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setString(3, designation);
            ps.setInt(4, salary);
            ps.setString(5, department);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Employee added.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void displayEmployees() {
        try (Connection conn = DBConnection.getConnection()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM employees");
            String message = "";
            while (rs.next()) {
                message += "Name: " + rs.getString("name") + "\n";
                message += "ID: " + rs.getInt("id") + "\n";
                message += "Designation: " + rs.getString("designation") + "\n";
                message += "Salary: " + rs.getInt("salary") + "\n";
                message += "Department: " + rs.getString("department") + "\n\n";
            }
            if (message.isEmpty()) message = "No employees found.";
            JOptionPane.showMessageDialog(this, message);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void searchEmployee() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("Enter Employee ID to search:"));
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM employees WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String message = "Name: " + rs.getString("name") + "\n"
                        + "ID: " + rs.getInt("id") + "\n"
                        + "Designation: " + rs.getString("designation") + "\n"
                        + "Salary: " + rs.getInt("salary") + "\n"
                        + "Department: " + rs.getString("department") + "\n";
                JOptionPane.showMessageDialog(this, message);
            } else {
                JOptionPane.showMessageDialog(this, "Employee not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void editEmployee() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("Enter Employee ID to edit:"));
        String[] options = {"Name", "Designation", "Salary", "Department"};
        int choice = JOptionPane.showOptionDialog(this, "Choose field to edit:", "Edit", 0, 3, null, options, options[0]);
        String column = "";
        String newValue = "";

        switch (choice) {
            case 0: column = "name"; newValue = JOptionPane.showInputDialog("New Name:"); break;
            case 1: column = "designation"; newValue = JOptionPane.showInputDialog("New Designation:"); break;
            case 2: column = "salary"; newValue = JOptionPane.showInputDialog("New Salary:"); break;
            case 3: column = "department"; newValue = JOptionPane.showInputDialog("New Department:"); break;
            default: return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE employees SET " + column + " = ? WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            if (column.equals("salary")) {
                ps.setInt(1, Integer.parseInt(newValue));
            } else {
                ps.setString(1, newValue);
            }
            ps.setInt(2, id);
            int updated = ps.executeUpdate();
            if (updated > 0) JOptionPane.showMessageDialog(this, "Employee updated.");
            else JOptionPane.showMessageDialog(this, "Employee not found.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteEmployee() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("Enter Employee ID to delete:"));
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "DELETE FROM employees WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            int deleted = ps.executeUpdate();
            if (deleted > 0) JOptionPane.showMessageDialog(this, "Employee deleted.");
            else JOptionPane.showMessageDialog(this, "Employee not found.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new EmployeeManagementGUI();
    }
}
